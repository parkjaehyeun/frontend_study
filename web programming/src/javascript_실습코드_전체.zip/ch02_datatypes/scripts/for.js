for (var x = 8; x < 10; x++) {
  console.log('x의 값은 ' + x);
}


for (var i = 1, j = 1; i < 5; i++, j++) {
  console.log('i * j는'+ i * j);
}
