var rank = 'B';
switch(rank) {
  case 'A' :
    console.log('A랭크입니다.');
    break;
  case 'B' :
    console.log('B랭크입니다.');
    break;
  case 'C' :
    console.log('C랭크입니다.');
    break;
  default :
    console.log('아무 랭크도 아닙니다.');
    break;
}

var x = '0';
switch (x) {
  case 0 :
    console.log('숫자 0이다.');
    break;
    case '0' :
      console.log('문자 0이다.');
      break;
}
