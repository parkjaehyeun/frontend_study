var x = 8;
while(x < 10) {
  console.log('x의 값은 ' + x);
  x++;
}
