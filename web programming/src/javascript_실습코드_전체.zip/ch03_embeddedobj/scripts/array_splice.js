var data = ['Sato', 'Takae', 'Osada', 'Hio', 'Saitoh'];
console.log(data.splice(3, 2, 'Yamada', 'Suzuki'));
console.log(data);
console.log(data.splice(3, 2));
console.log(data);
console.log(data.splice(1, 0, 'Tanaka'));
console.log(data);
