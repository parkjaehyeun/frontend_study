// stack
var data = [];
data.push(1);
data.push(2);
data.push(3);
console.log(data.pop());
console.log(data.pop());
console.log(data.pop());

// queue
var data = [];
data.push(1);
data.push(2);
data.push(3);
console.log(data.shift());
console.log(data.shift());
console.log(data.shift());